#ifndef __SLLIST_H_
#define __SLLIST_H_
struct Node {
void *data;
struct Node *next;
};

struct SLList {
struct Node *head;
struct Node *tail_node;
int length;
};

static inline void init_list(struct SLList *list) {
list->head = NULL;
list->tail_node = NULL;
list->length = 0;
}

static inline int is_empty(struct SLList *list) {
return (list->head == NULL);
}

struct Node *add_front(struct SLList *list, void *data);

struct Node *add_back(struct SLList *list, void *data);
d traverse(struct SLList *list, void (*f)(void *));

void *pop_front(struct SLList *list);
#endif
