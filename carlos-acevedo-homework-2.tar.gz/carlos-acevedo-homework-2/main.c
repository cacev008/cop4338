#include <stdlib.h>
#include "bmplib.h"
#include <math.h>
#include <stdio.h>
#include <getopt.h>
#include <unistd.h>

/*
* This method enlarges a 24-bit, uncompressed .bmp file
* that has been read in using readFile()
*
* original - an array containing the original PIXELs, 3 bytes per each
* rows - the original number of rows
* cols - the original number of columns
*
* scale - the multiplier applied to EACH OF the rows and columns, e.g.
* if scale=2, then 2* rows and 2*cols
*
* new - the new array containing the PIXELs, allocated within
* newrows - the new number of rows (scale*rows)
* newcols - the new number of cols (scale*cols)
*/

int enlarge(PIXEL* original, int rows, int cols, int scale,
PIXEL** new, int* newrows, int* newcols)
{

int row, col, i, j;

if ((rows <= 0) || (cols <= 0))
{
return -1;
}

*newrows = rows*scale;
*newcols = cols*scale;

*new = (PIXEL*)malloc((scale*rows)*(scale*cols)*sizeof(PIXEL));

for (row=0; row<rows; row++)
{
for (col=0; col<cols; col++)
{
PIXEL *o = original + row*cols + col;

for (j=0; j<scale; j++)
{
for (i=0; i<scale; i++)
{
PIXEL *n = (*new) + (row*scale + i)*(*newcols) + (col*scale + j);
*n = *o;
}
}
}
}
return 0;
}


/*
* This method rotates a 24-bit, uncompressed .bmp file that has been read
* in using readFile(). The rotation is expressed in degrees and can be
* positive, negative, or 0 -- but it must be a multiple of 90 degrees
*
* original - an array containing the original PIXELs, 3 bytes per each
* rows - the number of rows
* cols - the number of columns
* rotation - a positive or negative rotation,
*
* new - the new array containing the PIXELs, allocated within
* newrows - the new number of rows
* newcols - the new number of cols
*/

int rotate(PIXEL* original, int rows, int cols, int rotation,
PIXEL** new, int* newrows, int* newcols)
{
int row, col, rot = rotation/90;

if ((rows <= 0) || (cols <= 0))
{
return -1;
}

if (rot%2 == 0)
{
*newrows = rows;
*newcols = cols;
}

else
{
*newrows = cols;
*newcols = rows;
}

rot = rot%4;

*new = (PIXEL*)malloc((*newrows)*(*newcols)*sizeof(PIXEL));

for (row = 0; row < rows; row++)
{
for (col = 0; col < cols; col++)
{
PIXEL* o = original + row*cols + col;
PIXEL* n;
switch(rot)
{
case -3:
case 1:
n = (*new) + (cols-1-col)*rows + row;
*n = *o;
break;
case -2:
case 2:
n = (*new) + (rows-1-row)*cols + (cols-1-col);
*n = *o;
break;
case -1:
case 3:
n = (*new) + (rows*col) + (rows-1-row);
*n = *o;
break;
case 0:
n = (*new) + (row*cols) + col;
*n = *o;
break;
}
}
}

return 0;
}

/*
* This method horizontally flips a 24-bit, uncompressed bmp file
* that has been read in using readFile().
*
* THIS IS GIVEN TO YOU SOLELY TO LOOK AT AS AN EXAMPLE
* TRY TO UNDERSTAND HOW IT WORKS
*
* original - an array containing the original PIXELs, 3 bytes per each
* rows - the number of rows
* cols - the number of columns
*
* new - the new array containing the PIXELs, allocated within
*/

int flip (PIXEL *original, PIXEL **new, int rows, int cols)
{
int row, col;

if ((rows <= 0) || (cols <= 0)) return -1;

*new = (PIXEL*)malloc(rows*cols*sizeof(PIXEL));

for (row=0; row < rows; row++)
for (col=0; col < cols; col++) {
PIXEL* o = original + row*cols + col;
PIXEL* n = (*new) + row*cols + (cols-1-col);
*n = *o;
}

return 0;
}

/*
* This method extracts a rectangular portion of a 24-bit, uncompressed bmp file
* that has been read in using readFile(), with a certain initial point, a width
* and a length.
*
* original - an array containing the original PIXELs, 3 bytes per each
* rows - the number of rows
* cols - the number of columns
* ptx - a coordinate of the initial point for the extraction
* pty - a coordinate of the initial point for the extraction
* width - width of the extraction
* length - length of the extraction
* new - the new array containing the PIXELs, allocated within
* newrows - the new rows of the extraction
* newcols - the new columns of the extraction
*/

int main(int argc, char *argv[])
{
extern char *optarg;
extern int optind;

int degree = 0, scale = 0, ferror = 0;
int is_rotate = 0, is_scale = 0, is_flip = 0;
char *inputFile = NULL, *outputFile = NULL;

int r, c;
int nr=0, nc=0;
PIXEL *b, *nb = NULL;

while ((c = getopt(argc, argv, "s:r:f:o")) != -1)
{
switch (c)
{
case 's':
is_scale = 1;
sscanf (optarg,"%d",&scale);
if(scale < 0)
{
printf("bmptool: -n %s: resize factor must be positive integer.\n", optarg);
ferror = 1;
}
break;
case 'r':
is_rotate = 1;
sscanf (optarg,"%d",&degree);
if(degree%90 != 0)
{
printf("bmptool: -n %s: rotation angle must be multiple of 90 degree.\n", optarg);
ferror = 1;
}
break;
case 'f':
is_flip = 1;
break;
case 'o':
outputFile = optarg;
break;
case '?':
ferror = 1;
break;
}
}

if(ferror == 1)
{
return 0;
}

inputFile = argv[optind];

readFile(inputFile, &r, &c, &b);

if(is_scale == 1)
{
enlarge(b, r, c, scale, &nb, &nr, &nc);
}

if(is_rotate == 1 && nb != NULL && nr != 0 && nc != 0)
{
rotate(nb, nr, nc, degree, &nb, &nr, &nc);
}

else if(is_rotate == 1 && nb != NULL)
{
rotate(nb, r, c, degree, &nb, &nr, &nc);
}

else if(is_rotate == 1)
{
rotate(b, r, c, degree, &nb, &nr, &nc);
}

if(is_flip == 1 && nb != NULL)
{
flip(nb, &nb, nr, nc);
}

else if(is_flip == 1)
{
nr = r;
nc = c;
flip(b, &nb, nr, nc);
}

if(nb != NULL && nr != 0 && nc != 0)
{
writeFile(outputFile, nr, nc, nb);
}

else
{
writeFile(outputFile, r, c, b);
}

free(b);
free(nb);

return 0;
}

