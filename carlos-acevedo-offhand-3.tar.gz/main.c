#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main() 
{
int pipes[2];
pid_t childprocess1, childprocess2;

int p = pipe(pipes);
if (p<0)
{
fprintf(stderr, "PIPE FAIL");
exit(2);
}


childprocess2 = fork();
if(childprocess2 < 0)
{
fprintf(stderr, "CHILD2 FORK FAILED\n\n");
exit(3);
}

else if(childprocess2 > 0)
{
childprocess1 = fork(); 
if(childprocess1 <0)
{
fprintf(stderr, "CHILD1 FORK FAILED\n\n");
exit(4);
}
else if(childprocess1 ==0)
{
dup2(pipes[1], 1);
close(pipes[0]);
execlp("/bin/ls", "ls", "-l", NULL);
}
wait(NULL);
}
else if(childprocess2 ==0)
{ 
dup2(pipes[0],0);
close(pipes[1]);
execlp("sort", "sort", NULL);
}

return 0;
}
